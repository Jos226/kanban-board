<?php

namespace App\Repositories;

class BaseRepository
{

}
