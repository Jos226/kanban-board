#!/bin/sh

# Install the Chrome Binary release to support Chrome-based API.
# The binary will be available at this path: /usr/bin/google-chrome-stable

# curl https://gist.githubusercontent.com/rennokki/813867e8d5572d0ea51b1551dc27cd2a/raw/e368c5a6a12e22739247a97d9bf21ca399224da9/install_latest_chrome_binary.sh | sudo bash
