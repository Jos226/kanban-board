#!/bin/sh

# This file will make sure to restart on specific services like NGINX.
# During postdeploy, we make sure to restart the services to take in consideration the new custom configs.
# Please see the related issue(s): https://github.com/rennokki/laravel-aws-eb/issues/55

# Feel free to uncomment the following lines in case you have issues. ¯\_(ツ)_/¯

# sudo systemctl restart nginx.service
